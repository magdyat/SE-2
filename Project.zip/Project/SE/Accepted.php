<hhtml>
<style>

</style>
<link rel="stylesheet" href="style.css">

<body>
  <h1>IF you received an acceptence e-mail please fill these info :<h1>
<section class="card" style="background-color:  #D8E0E8">
  <form action="Acceptedins.php" method="post">
  ID (Received via Mail):<br>
  <input type="text" name="ID"><br>
   Full Name:<br>
   <input type="text" name="fullname"><br>
   Degree to be Acquired:<br>
   <input type="text" name="Degree"><br>

     Subjects:<br>
     <input type="text" name="Subjects"><br>

     <input type="submit" value="Submit">
   </form>
