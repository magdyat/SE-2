<html>
<style>

</style>
<link rel="stylesheet" href="style.css">

<body>
<section class="card" style="background-color:  #D8E0E8">
  <form action="insert.php" method="post">
  First Name:<br>
  <input type="text" name="firstname"><br>
   last Name:<br>
   <input type="text" name="lastname"><br>
  Phone number:<br>
  <input type="number" name="phone"><br>
  E-mail:<br>
   <input type="text" name="email"><br>
  Age:<br>
  <input type="number" name="age"><br>
  Graduation date:<br>
   <input type="date" name="graduation"><br>
  Birth date:<br>
  <input type="date" name="birth"><br>
  Address :<br>
  <input type="text" name="address"><br>
    Governorate:<br>
    <input type="text" name="governorate"><br>
    Nationality:
    <input type="text" name="nationality"><br>
    National ID:
    <input type="text" name="N_ID"><br>
    Current Job:
    <input type="text" name="job"><br>
    <center><h3>   University Degrees   </h3></center><br>

    Bachelore:
    <input type="text" name="bachelore"><br>
    Overall GPA:
    <input type="text" name="gpa"><br>
    University:
    <input type="text" name="university"><br>
    Faculty:
    <input type="text" name="faculty"><br>
    Postgraduate Studies:
    <input type="text" name="h_studies"><br>
    Overall  GPA:
    <input type="text" name="gpa1"><br>
    University:
    <input type="text" name="university1"><br>
    Faculty:
    <input type="text" name="faculty1"><br>
    Department:
    <input type="text" name="department"><br>




  <center><input type="submit" class="cta-button"></center>
  </form>



</section>
</body>
</html>
